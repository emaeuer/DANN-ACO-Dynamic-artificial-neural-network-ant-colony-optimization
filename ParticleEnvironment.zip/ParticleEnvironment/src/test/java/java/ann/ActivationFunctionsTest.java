package java.ann;

public class ActivationFunctionsTest {
}
