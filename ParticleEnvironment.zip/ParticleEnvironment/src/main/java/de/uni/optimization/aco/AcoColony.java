package de.uni.optimization.aco;

import de.uni.ann.NeuralNetwork;
import de.uni.optimization.aco.pheromone.CompositePheromoneMatrix;
import de.uni.optimization.aco.pheromone.LayerPheromoneMatrix;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

public class AcoColony {

    private static final AtomicInteger NEXT_COLONY_NUMBER = new AtomicInteger(0);

    private final int colonyNumber = NEXT_COLONY_NUMBER.getAndIncrement();

    private int size;

    private final CompositePheromoneMatrix pheromoneMatrix;

    private final List<Ant> currentAnts = new ArrayList<>();

    private NeuralNetwork nn;

    public AcoColony(NeuralNetwork nn, int colonySize) {
        this.size = colonySize;

        this.nn = nn;
        nn.randomize();

        this.pheromoneMatrix = CompositePheromoneMatrix.buildForNeuralNetwork(this.nn);
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public CompositePheromoneMatrix getPheromoneMatrix() {
        return this.pheromoneMatrix;
    }

    public List<Ant> generateSolutions() {
        this.currentAnts.clear();

        IntStream.range(0, this.size)
                // create ants
                .mapToObj(i -> new Ant(this.nn.copy(), this.pheromoneMatrix))
                .peek(ant -> ant.setColonyNumber(this.colonyNumber))
                .peek(Ant::walk)
                .forEach(this.currentAnts::add);
        return this.currentAnts;
    }

    public void update() {
        double avgQuality = this.currentAnts.stream()
                .mapToDouble(Ant::getFitness)
                .average()
                .orElse(0);

        // TODO remove max is just informational
        double maxQuality = this.currentAnts.stream()
                .mapToDouble(Ant::getFitness)
                .max()
                .orElse(0);

        System.out.println("Average quality: " + avgQuality + " Max quality: " + maxQuality);

        // all update according to the average
        this.currentAnts.stream()
                .filter(ant -> ant.getFitness() == maxQuality)
                .limit(1)
                .peek(ant -> this.nn = ant.getNeuralNetwork())
                .forEach(ant -> {
                    this.pheromoneMatrix.updateSolution(ant.getSolution(), ant.getFitness() - avgQuality);
                });

        // dissipate pheromone
        this.pheromoneMatrix.stream()
                .forEach(LayerPheromoneMatrix::dissipate);
    }
}
