package de.uni.optimization.aco;

import de.uni.ann.NeuralNetwork;
import de.uni.optimization.OptimizationMethod;
import de.uni.optimization.Solution;
import de.uni.optimization.aco.pheromone.CompositePheromoneMatrix;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AcoHandler implements OptimizationMethod {

    private final NeuralNetwork nn;

    private final List<AcoColony> colonies = new ArrayList<>();

    public AcoHandler(NeuralNetwork network, int numberOfColonies, int colonySize) {
        this.nn = network.copy();

        for (int i = 0; i < numberOfColonies; i++) {
            colonies.add(new AcoColony(this.nn, colonySize));
        }
    }

    @Override
    public List<Solution> generateSolutions() {
        return this.colonies.stream()
                .map(AcoColony::generateSolutions)
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }

    @Override
    public void update() {
        this.colonies.forEach(AcoColony::update);
    }


}
